//
//  RecipeViewController.h
//  CustomTableView
//
//  Created by Simon on 1/1/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecipeViewController : UITableViewController

@end
