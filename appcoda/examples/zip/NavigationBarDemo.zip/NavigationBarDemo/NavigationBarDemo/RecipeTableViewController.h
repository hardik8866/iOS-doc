//
//  RecipeTableViewController.h
//  NavigationBarDemo
//
//  Created by Simon on 2/10/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecipeTableViewController : UITableViewController

@end
