//
//  SecondViewController.h
//  DynamicsDemo
//
//  Created by Gabriel Theodoropoulos on 7/3/14.
//  Copyright (c) 2014 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>

@end
