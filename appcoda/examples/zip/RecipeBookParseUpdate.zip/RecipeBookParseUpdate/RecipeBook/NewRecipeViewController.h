//
//  NewRecipeViewController.h
//  RecipeBook
//
//  Created by Simon on 10/8/13.
//
//

#import <UIKit/UIKit.h>

@interface NewRecipeViewController : UITableViewController <UINavigationControllerDelegate, UIImagePickerControllerDelegate, UITextFieldDelegate>

@end
