#A simple demo for IBDesignable and IBInspectable

With the release of Xcode 6, Apple introduced a new feature known as IBDesignable and IBInspectable for developers to build custom controls and allowed us to live preview the design right in the Interface Builder. Quite obviously, this is a huge productivity benefit.

In this tutorial, I will give you an introduction to IBDesignable and IBInspectable, and show you guys how to take advantage of the new feature. There is no better way to elaborate a feature than creating a demo. So here it is. For details of the tutorial, you can refer to:

http://www.appcoda.com/ibdesignable-ibinspectable-tutorial/
