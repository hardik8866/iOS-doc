//
//  ViewController.h
//  StaticTableDemo
//
//  Created by Simon on 16/3/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
