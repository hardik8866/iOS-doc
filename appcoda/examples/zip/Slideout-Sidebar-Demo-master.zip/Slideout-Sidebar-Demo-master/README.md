Slideout Sidebar Demo
=====================

A simple demo on how to add a Slide-out Sidebar Menu in iOS Apps using SWRevealViewController (https://github.com/John-Lluch/SWRevealViewController)

For the details of the implementation, please refer to this tutorial:

http://www.appcoda.com/ios-programming-sidebar-navigation-menu/
