//
//  ViewController.h
//  SidebarDemo
//
//  Created by Simon Ng on 9/11/14.
//  Copyright (c) 2014 AppCoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

