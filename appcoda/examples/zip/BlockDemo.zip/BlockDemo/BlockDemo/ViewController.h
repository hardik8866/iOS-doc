//
//  ViewController.h
//  BlockDemo
//
//  Created by Gabriel Theodoropoulos on 19/1/14.
//  Copyright (c) 2014 AppCoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)showActionSheet:(id)sender;

@end
