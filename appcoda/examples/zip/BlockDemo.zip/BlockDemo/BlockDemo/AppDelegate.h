//
//  AppDelegate.h
//  BlockDemo
//
//  Created by Gabriel Theodoropoulos on 19/1/14.
//  Copyright (c) 2014 AppCoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
