//
//  AnimalTableTableViewController.h
//  IndexedTableDemo
//
//  Created by Simon on 16/3/14.
//  Copyright (c) 2014 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnimalTableTableViewController : UITableViewController

@end
