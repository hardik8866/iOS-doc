//
//  DismissingAnimationController.h
//  POPDemo
//
//  Created by Simon Ng on 22/12/14.
//  Copyright (c) 2014 AppCoda. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <pop/POP.h>

@interface DismissingAnimationController : NSObject <UIViewControllerAnimatedTransitioning>

@end
