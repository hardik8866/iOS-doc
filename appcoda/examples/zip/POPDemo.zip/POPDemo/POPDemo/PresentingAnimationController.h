//
//  PresentingAnimationController.h
//  POPDemo
//
//  Created by Simon Ng on 22/12/14.
//  Copyright (c) 2014 AppCoda. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "POP.h"

@interface PresentingAnimationController : NSObject <UIViewControllerAnimatedTransitioning>

@end
