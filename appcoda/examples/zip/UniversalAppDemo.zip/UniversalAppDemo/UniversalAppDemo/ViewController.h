//
//  ViewController.h
//  UniversalAppDemo
//
//  Created by Simon on 17/10/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)play:(id)sender;

@end
