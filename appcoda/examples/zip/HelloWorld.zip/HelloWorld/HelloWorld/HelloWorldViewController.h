//
//  HelloWorldViewController.h
//  HelloWorld
//
//  Created by Simon Ng on 9/4/12.
//  Copyright (c) 2012 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelloWorldViewController : UIViewController

-(IBAction)showMessage;

@end
