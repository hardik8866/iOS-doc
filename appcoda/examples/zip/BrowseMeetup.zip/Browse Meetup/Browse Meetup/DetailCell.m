//
//  DetailCell.m
//  BrowseMeetup
//
//  Created by TAMIM Ziad on 8/16/13.
//  Copyright (c) 2013 TAMIM Ziad. All rights reserved.
//

#import "DetailCell.h"

@implementation DetailCell

@end
