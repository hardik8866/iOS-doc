//
//  WeatherDataKit.h
//  WeatherDataKit
//
//  Created by Joyce Echessa on 10/17/14.
//  Copyright (c) 2014 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for WeatherDataKit.
FOUNDATION_EXPORT double WeatherDataKitVersionNumber;

//! Project version string for WeatherDataKit.
FOUNDATION_EXPORT const unsigned char WeatherDataKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WeatherDataKit/PublicHeader.h>


