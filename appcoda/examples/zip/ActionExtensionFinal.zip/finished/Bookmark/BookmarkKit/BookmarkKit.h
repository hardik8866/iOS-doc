//
//  BookmarkKit.h
//  BookmarkKit
//
//  Created by Joyce Echessa on 3/9/15.
//  Copyright (c) 2015 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BookmarkKit.
FOUNDATION_EXPORT double BookmarkKitVersionNumber;

//! Project version string for BookmarkKit.
FOUNDATION_EXPORT const unsigned char BookmarkKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BookmarkKit/PublicHeader.h>


