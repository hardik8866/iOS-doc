# A simple demo for Google Maps API

This is a demo to show you how to integrate Google Maps SDK for iOS in your Swift project. We have written up a detailed tutorial here:

http://www.appcoda.com/google-maps-api-tutorial
