# React Native Demo App for iOS

Facebook open sourced React Native which is a framework that lets you 
build native iOS and Android (at the moment Android support is still under 
development) applications with JavaScript.

This is a simple demo app built with React Native. For details, please refer to this tutorial:

http://www.appcoda.com/react-native-introduction
